﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebTrackED_CHED_MIMAROPA.Model.Entities
{
    public class Sender:BaseEntity
    {

        [ForeignKey("User")]
        public string IdentityUserId { get; set; }
        public virtual AppIdentityUser User { get; set; }
        public virtual ICollection<DocumentAttachment> Documents { get; set; }
    }
}
