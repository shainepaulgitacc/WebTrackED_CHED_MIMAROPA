﻿using System.ComponentModel.DataAnnotations.Schema;
namespace WebTrackED_CHED_MIMAROPA.Model.Entities
{
    public class BaseEntity
    {
        public int Id { get; set; }
        public DateTime AddedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
    public enum Gender
    {
        Male,
        Female,
        NonBinary,
        Genderqueer,
        Genderfluid,
        Agender,    
        Bigender
    }
    public enum Prioritization
    {
        Usual,
        Urgent
    }
    public enum ReviewerStatus
    {
        ToReceived,
        OnReview,
        Reviewed,
        Approved,
        Disapproved
    }
    public enum Status
    {
        Pending,
        OnProcess,
        Approved,
        Disapproved
    }
}
