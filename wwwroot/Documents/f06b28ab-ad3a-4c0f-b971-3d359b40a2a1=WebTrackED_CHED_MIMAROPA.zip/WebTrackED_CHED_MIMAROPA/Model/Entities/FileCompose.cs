﻿namespace WebTrackED_CHED_MIMAROPA.Model.Entities
{
    public class FileCompose:BaseEntity
    {

    }
}
