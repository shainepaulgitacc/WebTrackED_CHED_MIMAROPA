﻿using WebTrackED_CHED_MIMAROPA.Data;
using WebTrackED_CHED_MIMAROPA.Model.Entities;
using WebTrackED_CHED_MIMAROPA.Model.Repositories.Contracts;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.ListViewModel;

namespace WebTrackED_CHED_MIMAROPA.Model.Repositories.Implementation
{
    public class CHEDPersonelRepository : BaseRepository<CHEDPersonel>, ICHEDPersonelRepository
    {
        private readonly ApplicationDbContext _db;
        public CHEDPersonelRepository(
            ApplicationDbContext db) : base(db)
        {
            _db = db;
        }
        public async Task<IEnumerable<CHEDPersonelListViewModel>> CHEDPersonelRecords()
        {
            var personels = _db.CHEDPersonels.ToList();
            var designations = _db.Designations.ToList();
            var offices = _db.Offices.ToList();
            var accounts = _db.Set<AppIdentityUser>();
            return personels
                .GroupJoin(designations,
                personel => personel.DesignationId,
                desig => desig.Id,
                (personel, desig) => new
                {
                    Personel = personel,
                    Designation = desig.FirstOrDefault(),
                })
                .GroupJoin(offices,
                result => result.Personel.OfficeId,
                office => office.Id,
                (result, office) => new
                {
                    Personel = result.Personel,
                    Designation = result.Designation,
                    Office = offices.FirstOrDefault()
                })
                .Join(accounts,
                result => result.Personel.IdentityUserId,
                account => account.Id,
                (result, account) => new
                {
                    Personel = result.Personel,
                    Designation = result.Designation,
                    Office = result.Office,
                    Account = account
                })
                .Select(x => new CHEDPersonelListViewModel
                {
                    CHEDPersonel = x.Personel,
                    Designation = x.Designation,
                    Office = x.Office,
                    Account = x.Account
                })
                .ToList();
        }
    }
}
