﻿namespace WebTrackED_CHED_MIMAROPA.Model.ViewModel.ViewComponentModel
{
    public class BreadCrumpViewModel
    {
        public string pageName { get; set; }
        public (string, string?, string,bool,string?)[]? breadCrump { get; set; }
        public DateTime date { get; set; }
    }
}
