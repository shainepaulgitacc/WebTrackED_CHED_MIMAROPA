﻿namespace WebTrackED_CHED_MIMAROPA.Model.ViewModel.ListViewModel
{
    public class DeleteModalViewModel
    {
        public string Id { get; set; }
        public string? returnUrl { get; set; }
    }
}
