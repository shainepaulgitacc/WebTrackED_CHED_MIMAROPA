﻿using WebTrackED_CHED_MIMAROPA.Model.Entities;

namespace WebTrackED_CHED_MIMAROPA.Model.ViewModel.ListViewModel
{
    public class SenderListViewModel
    {
        public Sender Sender { get; set; }
        public AppIdentityUser User { get; set; }
    }
}
