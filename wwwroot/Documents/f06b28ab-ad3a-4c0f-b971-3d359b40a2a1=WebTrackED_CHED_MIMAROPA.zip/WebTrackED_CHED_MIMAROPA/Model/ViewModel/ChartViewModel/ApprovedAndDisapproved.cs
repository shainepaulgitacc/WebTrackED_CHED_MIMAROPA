﻿namespace WebTrackED_CHED_MIMAROPA.Model.ViewModel.ChartViewModel
{
    public class ApprovedDisapproved
    {
        public int CountApproved { get; set; }
        public int CountDisapproved { get; set; }
    }
}
