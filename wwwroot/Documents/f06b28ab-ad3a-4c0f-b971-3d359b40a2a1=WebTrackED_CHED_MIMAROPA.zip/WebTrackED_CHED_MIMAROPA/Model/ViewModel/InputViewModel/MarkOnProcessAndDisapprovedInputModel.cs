﻿namespace WebTrackED_CHED_MIMAROPA.Model.ViewModel.InputViewModel
{
    public class MarkOnProcessAndDisapprovedInputModel
    {
        public string PrevPage { get;  set; }
        public string Id { get; set; }
    }
}
