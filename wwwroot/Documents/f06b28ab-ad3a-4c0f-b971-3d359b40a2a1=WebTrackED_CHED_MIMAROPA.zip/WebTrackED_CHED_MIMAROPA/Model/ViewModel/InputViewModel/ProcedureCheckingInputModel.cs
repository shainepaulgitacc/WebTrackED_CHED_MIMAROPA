﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WebTrackED_CHED_MIMAROPA.Model.ViewModel.InputViewModel
{
    public class ProcedureCheckingInputModel
    {
        public string SelectedIds { get; set; }
        public int? OldReviewer { get; set; }
        [Required,DisplayName("NewReviewer")]
        public int? NewReviewer { get; set; }
        public int DocumentId { get; set; }
    }
}
