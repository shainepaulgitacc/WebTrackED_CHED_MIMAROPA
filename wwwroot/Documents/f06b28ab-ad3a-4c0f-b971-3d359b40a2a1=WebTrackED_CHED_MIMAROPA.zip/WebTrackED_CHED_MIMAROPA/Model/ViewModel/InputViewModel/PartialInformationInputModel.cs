﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WebTrackED_CHED_MIMAROPA.Model.ViewModel.InputViewModel
{
    public class PartialInformationInputModel
    {
        public string IdentityUserId { get; set; }

        [Required, DisplayName("First Name")]
        public string FirstName { get; set; }
        [DisplayName("Middle Name")]
        public string? MiddleName { get; set; }
        public string? Suffixes { get; set; }
        [DisplayName("Last Name")]
        public string? LastName { get; set; }
    }
}
