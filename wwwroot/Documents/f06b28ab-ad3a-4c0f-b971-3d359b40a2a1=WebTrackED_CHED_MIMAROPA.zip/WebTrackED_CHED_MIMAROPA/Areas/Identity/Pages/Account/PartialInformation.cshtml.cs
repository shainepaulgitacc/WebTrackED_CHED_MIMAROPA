﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.
#nullable disable

using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.WebUtilities;
using WebTrackED_CHED_MIMAROPA.Model.Entities;
using WebTrackED_CHED_MIMAROPA.Model.Repositories.Contracts;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.InputViewModel;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.InputViewModel.BaseIdentityUser;

namespace WebTrackED_CHED_MIMAROPA.Areas.Identity.Pages.Account
{
    [ValidateAntiForgeryToken]
    public class PartialInformationModel: PageModel
    {
        private readonly IBaseRepository<CHEDPersonel> _chedPRepo;
        private readonly IBaseRepository<Sender> _senderRepo;
        private readonly IBaseRepository<AppIdentityUser> _accountRepo;
        private readonly IBaseRepository<Office> _officeRepo;
        private readonly IBaseRepository<Designation> _desigRepo;
        private readonly UserManager<AppIdentityUser> _userManager;
        private readonly SignInManager<AppIdentityUser> _signInManager;
        private readonly IMapper _mapper;
        public PartialInformationModel(
            IBaseRepository<CHEDPersonel> chedPRepo,
            IBaseRepository<Sender> senderRepo,
            IBaseRepository<AppIdentityUser> accountRepo,
            IBaseRepository<Office> officeRepo,
            IBaseRepository<Designation> desigRepo,
            UserManager<AppIdentityUser> userManager,
            SignInManager<AppIdentityUser> signInManager,   
            IMapper mapper)
        {
            _signInManager = signInManager;
            _mapper = mapper;
            _accountRepo = accountRepo;
            _chedPRepo = chedPRepo;
            _senderRepo = senderRepo;
            _officeRepo = officeRepo;
            _desigRepo = desigRepo;
            _userManager = userManager;
        }
        [TempData]
        public string StatusMessage { get; set; }

        [BindProperty]
        public PartialInformationInputModel InputModel { get; set; }

        public List<Office> Offices { get; set; }
        public List<Designation> Designations { get; set; }
        public string Code { get; set; }
        public bool isZeroUser { get; set; }
        public async Task<IActionResult> OnGetAsync(string userId, string code)
        {
            var offices = await _officeRepo.GetAll();
            var designations = await _desigRepo.GetAll();
            var chedpersonels = await _chedPRepo.GetAll();
            var sender = await _senderRepo.GetAll();

            Offices = offices.ToList();
            Designations = designations.ToList();

            InputModel = new PartialInformationInputModel
            {
                IdentityUserId = userId
            };

            isZeroUser = chedpersonels.Count()<= 0 && sender.Count() <= 0;

            if (userId == null || code == null)
            {
                return RedirectToPage("/Index");
            }

            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{userId}'.");
            }

            Code = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(code));
            return Page();
        }
        public async Task<IActionResult> OnPostAsync(string code,string userType)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            if (userType.Contains("Admin"))
            {
               var converted = _mapper.Map<CHEDPersonel>(InputModel);
               await _chedPRepo.Add(converted);
            }
            else
            {
                var converted = _mapper.Map<Sender>(InputModel);
                await _senderRepo.Add(converted);
            }
            var user = await _userManager.FindByIdAsync(InputModel.IdentityUserId);
            user.FirstName = InputModel.FirstName;
            user.LastName = InputModel.LastName;
            user.MiddleName = InputModel.MiddleName;
            user.Suffixes = InputModel.Suffixes;
            user.Active = true;
            await _accountRepo.Update(user, user.Id);
            await _userManager.ConfirmEmailAsync(user, code);
            await _signInManager.SignInAsync(user, isPersistent: false);
            return RedirectToPage();
        }
    }
}
