using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebTrackED_CHED_MIMAROPA.Model.Entities;
using WebTrackED_CHED_MIMAROPA.Model.Repositories.Contracts;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.ListViewModel;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Usermanagement.Sender
{
    public class IndexModel : PageModel
    {
        private readonly ISenderRepository _sRepo;
        private readonly IBaseRepository<AppIdentityUser> _accRepo;
        private readonly UserManager<AppIdentityUser> _userManager;
        public IndexModel(
            ISenderRepository sRepo,
            UserManager<AppIdentityUser> userManager,
            IBaseRepository<AppIdentityUser> accRepo)
        {
            _sRepo = sRepo;
            _userManager = userManager;
            _accRepo = accRepo;
        }
        public List<SenderListViewModel> Senders { get; set; }
        public async Task OnGetAsync()
        {
            var senders = await _sRepo.SenderRecords();
            Senders = senders.Where(x => x.User.UserName != User.Identity?.Name).ToList();
        }
        public async Task<IActionResult> OnGetActivation(string accId, bool isActive)
        {
            var acc = await _accRepo.GetOne(accId);
            if (isActive)
            {
                acc.Active = false;

                await _userManager.UpdateSecurityStampAsync(acc);
            }
            else
            {
                acc.Active = true;
            }

            await _accRepo.Update(acc, acc.Id);
            TempData["validation-message"] = "Successfully perform action";
            return RedirectToPage();
        }
    }
}
