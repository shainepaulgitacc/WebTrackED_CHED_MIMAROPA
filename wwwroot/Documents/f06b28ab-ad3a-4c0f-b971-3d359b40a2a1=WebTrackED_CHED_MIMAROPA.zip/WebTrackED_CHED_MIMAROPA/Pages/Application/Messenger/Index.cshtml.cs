using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.IdentityModel.Tokens;
using WebTrackED_CHED_MIMAROPA.Model.Entities;
using WebTrackED_CHED_MIMAROPA.Model.Repositories.Contracts;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.InputViewModel;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.ListViewModel;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Messenger
{
    public class IndexModel : BasePageModel<Message, MessageInputModel>
    {
        private readonly IBaseRepository<AppIdentityUser> _userRepo;
        private readonly IMessageRepository _messRepo;
        private readonly UserManager<AppIdentityUser> _userManager;
       

        public IndexModel(
            IBaseRepository<AppIdentityUser> userRepo,
            IMessageRepository messRepo,
            UserManager<AppIdentityUser> userManager,
            IMapper mapper
          
            ) :base(messRepo,mapper)
        {
            _userRepo = userRepo;
            _messRepo = messRepo;
            _userManager = userManager;
           
        }

        public List<AppIdentityUser> Users { get; set; }
        public AppIdentityUser Recipient { get; set; }
        public string? RecipientId { get; set; }
        public string? SenderId { get; set; }
        public List<MessengerData> Messages { get; set; }
        public async Task OnGetAsync(string? pageId = null)
        {
            var users = await _userRepo.GetAll();
           
            var messages = await _messRepo.MessengerRecords();
            var user = await _userManager.FindByNameAsync(User.Identity?.Name);
            Users = users.Where(x => x.Id != user?.Id).ToList();
            Messages = messages.ToList();
            RecipientId = pageId ?? string.Empty;
            SenderId = user?.Id;

            if(pageId != null)
            {                
                Recipient = await _userManager.FindByIdAsync(pageId);

            }

        }



    }
}
