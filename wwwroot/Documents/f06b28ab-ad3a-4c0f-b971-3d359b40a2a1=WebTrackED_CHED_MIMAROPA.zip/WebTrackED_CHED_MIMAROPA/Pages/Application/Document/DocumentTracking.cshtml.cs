using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Identity.Client;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.Blazor;
using System.Linq;
using System.Xaml.Permissions;
using WebTrackED_CHED_MIMAROPA.Model.Entities;
using WebTrackED_CHED_MIMAROPA.Model.Repositories.Contracts;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.ListViewModel;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Document
{
    public class DocumentTrackingModel : PageModel
    {
        private readonly IDocumentTrackingRepository _docTrackRepo;
        private readonly IDocumentAttachmentRepository _docAttachmentRepo;
        private readonly IBaseRepository<DocumentProcedure> _docProcedureRepo;
        public DocumentTrackingModel(
            IDocumentTrackingRepository docTrackRepo,
            IDocumentAttachmentRepository docAttachmentRepo,
            IBaseRepository<DocumentProcedure> docProcedureRepo)
        {
            _docTrackRepo = docTrackRepo;
            _docAttachmentRepo = docAttachmentRepo;
            _docProcedureRepo = docProcedureRepo;
        }
        public string PreviousPage { get; set; }
        public List<DocumentTrackingViewModel> DocumentTrackings { get; set; }
        public List<DocumentProcedure> DocumentProcedures { get; set; }
        public DocumentAttachmentViewModel DocumentAttachment { get; set; }
        public int MaxId { get; set; }
        public async Task OnGetAsync(string prevPage, int docsId)
        {
            var documentProcedures = await _docProcedureRepo.GetAll();
            DocumentProcedures = documentProcedures
                .Where(x => x.DocumentAttachmentId == docsId)
                .ToList();
            PreviousPage = prevPage;
            var docsTrackings = await _docTrackRepo
                .DocumentTrackings();
            var filteredDocsTracking = docsTrackings
                .Where(x => x.DocumentAttachment.Id == docsId)
                .OrderByDescending(x => x.DocumentTracking.Id)
                .ToList();
            DocumentTrackings = filteredDocsTracking;
            var mxId = filteredDocsTracking.Max(x => x.DocumentTracking.Id);
            MaxId = mxId;
            var docsAttachment = await _docAttachmentRepo.DocumentAttachments();
            DocumentAttachment = docsAttachment
                .FirstOrDefault(x =>x.DocumentTracking.Id == mxId);
        }
    }
}
