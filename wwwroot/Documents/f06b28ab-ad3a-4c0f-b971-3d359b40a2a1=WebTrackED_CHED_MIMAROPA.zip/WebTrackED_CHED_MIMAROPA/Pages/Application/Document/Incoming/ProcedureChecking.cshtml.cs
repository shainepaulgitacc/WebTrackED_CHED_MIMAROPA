using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using WebTrackED_CHED_MIMAROPA.Model.Entities;
using WebTrackED_CHED_MIMAROPA.Model.Repositories.Contracts;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.InputViewModel;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.ListViewModel;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Document.Incoming
{
    public class ProcedureCheckingModel : PageModel
    {
        private readonly IBaseRepository<DocumentProcedure> _docsProcedRepo;
        private readonly IBaseRepository<DocumentTracking> _docsTrackRepo;
        private readonly ICHEDPersonelRepository _chedPRepo;
        private readonly UserManager<AppIdentityUser> _userManager;
        private readonly IDocumentAttachmentRepository _documentAttachmentRepository;
        private readonly IMapper _mapper;
        public ProcedureCheckingModel(
            IBaseRepository<DocumentProcedure> docsProcedRepo,
            IBaseRepository<DocumentTracking> docsTrackRepo,
            ICHEDPersonelRepository chedPRepo,
            UserManager<AppIdentityUser> userManager,
            IDocumentAttachmentRepository documentAttachmentRepository,
            IMapper mapper)
           
        {
            _docsProcedRepo = docsProcedRepo;
            _docsTrackRepo = docsTrackRepo;
            _chedPRepo = chedPRepo;
            _userManager = userManager;
            _documentAttachmentRepository = documentAttachmentRepository;
            _mapper = mapper;
        }
        public List<DocumentProcedure> documentProcedures { get; set; }
        public List<CHEDPersonelListViewModel> ChedPersonels { get; set; }
        public int DocsId { get; set; }
        public int OldReviewerId { get; set; }
        public string PreviousPage { get; set; }

        [BindProperty]
        public ProcedureCheckingInputModel InputModel { get; set; }

        public async Task<IActionResult> OnGetAsync(int docsId,string prevPage)
        {
            DocsId = docsId;
            PreviousPage = prevPage;
            var docProcedures = await _docsProcedRepo.GetAll();
            var chedPersonels = await _chedPRepo.CHEDPersonelRecords();
            var filtered = docProcedures.Where(x => x.DocumentAttachmentId == docsId).ToList();
            if (filtered.Count() <= 0)
                return BadRequest($"No procedure for now");
            documentProcedures = filtered;
            var account = await _userManager.FindByNameAsync(User.Identity?.Name);
            ChedPersonels = chedPersonels.Where(x => x.Account.Id != account?.Id).ToList();
            OldReviewerId = chedPersonels.FirstOrDefault(x =>x.Account.Id == account?.Id).CHEDPersonel.Id;
            return Page();
        }
        public async Task<IActionResult> OnPostAsync(int docsId)
        {
            if (!ModelState.IsValid)
            {
                TempData["validation-message"] = "Error make sure to select a new reviewer";
                return RedirectToPage("ProcedureChecking", new {docsId});
            }
            var docsProcedures = await _docsProcedRepo.GetAll();    
            foreach(var docprocedure in docsProcedures)
            {
                var splitedIds = InputModel.SelectedIds.Split(",");
                docprocedure.IsDone = splitedIds.Any(x => x == docprocedure.Id.ToString());
                await _docsProcedRepo.Update(docprocedure, docprocedure.Id.ToString());
            }
            await _docsTrackRepo.Add(new DocumentTracking
            {
                AddedAt = DateTime.Now,
                UpdatedAt = DateTime.Now,
                ReviewerId = (int)InputModel.OldReviewer,
                DocumentAttachmentId = InputModel.DocumentId,
                ReviewerStatus = ReviewerStatus.Reviewed
            });
            await _docsTrackRepo.Add(new DocumentTracking
            {
                AddedAt = DateTime.Now,
                UpdatedAt = DateTime.Now,
                ReviewerId = (int)InputModel.NewReviewer,
                DocumentAttachmentId = InputModel.DocumentId,
                ReviewerStatus = ReviewerStatus.ToReceived
            });
            TempData["validation-message"] = "Successfully passed to another reviewer";
            return RedirectToPage("/Application/Document/OutGoing/Index");
        }
        public async Task<IActionResult> OnGetApprovedDocument(string docsId,int rId)
        {
            var docattachment = await _documentAttachmentRepository.GetOne(docsId);
            if(docattachment == null)
                return BadRequest($"{docsId} this document attachment id is not found");
            docattachment.Status = Status.Approved;
            docattachment.UpdatedAt = DateTime.Now;
            var docsProcedures = await _docsProcedRepo.GetAll();
            var filteredDocProced = docsProcedures.Where(x => x.DocumentAttachmentId == docattachment.Id).ToList();
            foreach(var result in filteredDocProced)
            {
                result.IsDone = true;
                await _docsProcedRepo.Update(result,result.Id.ToString());
            }
            await _documentAttachmentRepository.Update(docattachment,docattachment.Id.ToString());
            await _docsTrackRepo.Add(new DocumentTracking
            {
                AddedAt = DateTime.Now,
                UpdatedAt = DateTime.Now,
                ReviewerId = rId,
                DocumentAttachmentId = int.Parse(docsId),
                ReviewerStatus = ReviewerStatus.Approved
            });
            TempData["validation-message"] = "Successfully approved";
            return RedirectToPage("/Application/Document/Ended/Index");
        }
    }
}
