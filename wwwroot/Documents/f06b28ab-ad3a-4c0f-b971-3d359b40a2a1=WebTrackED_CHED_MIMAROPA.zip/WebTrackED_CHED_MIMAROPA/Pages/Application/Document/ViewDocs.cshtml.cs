using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.CodeAnalysis.FlowAnalysis.DataFlow;
using System.Net.WebSockets;
using WebTrackED_CHED_MIMAROPA.Model.Entities;
using WebTrackED_CHED_MIMAROPA.Model.Repositories.Contracts;
using WebTrackED_CHED_MIMAROPA.Model.Service;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.InputViewModel;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.ListViewModel;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Document
{
    public class ViewDocsModel:BasePageModel<DocumentAttachment,DocumentAttachmentInputModel>
    {
        private readonly IDocumentAttachmentRepository _docRepo;
        private readonly IBaseRepository<DocumentTracking> _docTrackRepo;
        private readonly UserManager<AppIdentityUser> _userManager;
        private readonly IBaseRepository<CHEDPersonel> _reviewerRepo;
        private readonly FileUploader _fileUploader;
        private readonly IMapper _mapper;
        public ViewDocsModel(
            IDocumentAttachmentRepository docRepo,
            IBaseRepository<DocumentTracking> docTrackRepo,
            UserManager<AppIdentityUser> userManager,
            IBaseRepository<CHEDPersonel> reviewerRepo,
            FileUploader fileUploader,
            IMapper mapper):base(docRepo,mapper)
        {
            _docRepo = docRepo;
            _docTrackRepo   = docTrackRepo;
            _userManager = userManager;
            _reviewerRepo = reviewerRepo;   
            _fileUploader = fileUploader;
            _mapper = mapper;
        }
        public string PreviousPage { get; set; }

        [BindProperty]
        public IFormFile? NewDocuments { get; set; }

        [BindProperty]
        public Prioritization? Prioritization { get; set; }

        public DocumentAttachmentViewModel DocumentAttachment { get; set; }
        public Designation Designation { get; set; }
        public async Task<IActionResult> OnGetAsync(string prevPage ,int docsId)
        {
            PreviousPage = prevPage;
            var docsAttachments = await _docRepo.DocumentAttachments();
            var docAttachment = docsAttachments.OrderByDescending(x => x.DocumentTracking.Id).FirstOrDefault(x => x.DocumentAttachment.Id == docsId);
            if (docAttachment == null)
                return BadRequest($"{docsId} unknown DocumentAttachment");

            DocumentAttachment = docAttachment; 
            return Page();
        }
        public async Task<IActionResult>OnGetDownloadFile(string filename)
        {
            try
            {
                byte[] fileBytes = await _fileUploader.DownloadFile(filename);
                return File(fileBytes, "application/octet-stream", filename)
            }
            catch (FileNotFoundException ex)
            {
                return NotFound();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }
        #region --ViewDocument--
        /*public async Task<IActionResult>OnGetViewDocument(string filename)
        {
            try
            {
                var result = await _fileUploader.ViewFile(filename);
                return PhysicalFile(result.Item1,result.Item2);
            }
            catch (FileNotFoundException ex)
            {
                return NotFound();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }*/
        #endregion

        public async Task<IActionResult>OnPostChangeDocument(string prevPage, int docsId)
        {
            var docAttachment = await _docRepo.GetOne(docsId.ToString());

            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            docAttachment.FileName = await _fileUploader.Uploadfile(NewDocuments, "Documents");
            docAttachment.UpdatedAt = DateTime.Now;
            await _docRepo.Update(docAttachment, docAttachment.Id.ToString());
            TempData["validation-message"] = "Successfully replace document";
            return RedirectToPage("ViewDocs", new { prevPage, docsId });
        }
        public async Task<IActionResult> OnPostSetPrioritization(string prevPage, int docsId)
        {
            var docAttachment = await _docRepo.GetOne(docsId.ToString());

            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            docAttachment.Prioritization = Prioritization;
            docAttachment.UpdatedAt = DateTime.Now;
            await _docRepo.Update(docAttachment, docAttachment.Id.ToString());
            TempData["validation-message"] = "Successfully set prioritization";
            return RedirectToPage("ViewDocs", new { prevPage, docsId });
        }
        public async Task<IActionResult> OnGetMarkAsOnProcessOrDisapproved(string prevPage, string docsId,Status status)
        {
            var docAttachment = await _docRepo.GetOne(docsId);
            var account = await _userManager.FindByNameAsync(User.Identity?.Name);
            var reviewers = await _reviewerRepo.GetAll();
            var reviewer = reviewers.FirstOrDefault(x => x.IdentityUserId == account?.Id);
            docAttachment.Status = status;
            await _docTrackRepo.Add(new DocumentTracking
            {
                AddedAt = DateTime.Now,
                UpdatedAt = DateTime.Now,
                ReviewerId = reviewer.Id,
                DocumentAttachmentId = docAttachment.Id,
                ReviewerStatus = status == Status.OnProcess ? ReviewerStatus.OnReview: ReviewerStatus.Disapproved
            });
            await _docRepo.Update(docAttachment,docAttachment.Id.ToString());
            TempData["validation-message"] = status == Status.OnProcess ? "Successfully perform the action." : "Successfully disapproved document";
            if (status == Status.OnProcess)
                return RedirectToPage("ViewDocs", new { prevPage, docsId });
            else
                return RedirectToPage("/Application/Document/Ended/Index");
        }
    }
}
