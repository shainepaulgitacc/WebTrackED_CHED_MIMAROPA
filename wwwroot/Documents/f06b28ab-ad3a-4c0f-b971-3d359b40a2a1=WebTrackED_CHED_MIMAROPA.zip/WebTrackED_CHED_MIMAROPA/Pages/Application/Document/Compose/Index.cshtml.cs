using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.InputViewModel;
using WebTrackED_CHED_MIMAROPA.Model.Entities;
using WebTrackED_CHED_MIMAROPA.Model.Repositories.Contracts;
using AutoMapper;
using Microsoft.AspNetCore.Identity;
using WebTrackED_CHED_MIMAROPA.Model.Service;
using Microsoft.AspNetCore.Authorization;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.ListViewModel;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Document.Compose
{
    [Authorize(Roles ="Sender")]
    public class IndexModel : PageModel
    {
        private readonly IBaseRepository<DocumentAttachment> _repo;
        private readonly IBaseRepository<DocumentTracking> _docTrackingRepo;
        private readonly ICHEDPersonelRepository _chedRepo;
        private readonly IBaseRepository<Category> _categRepo;
        private readonly IBaseRepository<SubCategory> _scategRepo;
        private readonly IBaseRepository<Procedure> _procedureRepo;
        private readonly IBaseRepository<Sender> _senderRepo;
        private readonly UserManager<AppIdentityUser> _userManager;
        private readonly IMapper _mapper;
        private readonly FileUploader _fileUploader;
        private readonly IBaseRepository<DocumentProcedure> _docsProcedure;

        public IndexModel(
            IBaseRepository<DocumentAttachment> repo,
            ICHEDPersonelRepository chedRepo,
            IBaseRepository<Category> categRepo,
            IBaseRepository<Sender> senderRepo,
            IBaseRepository<SubCategory> scategRepo,
            IBaseRepository<Procedure> procedureRepo,
            UserManager<AppIdentityUser> userManager,
            IBaseRepository<DocumentTracking> docTrackingRepo,
            IMapper mapper,
            FileUploader fileUploader,
            IBaseRepository<DocumentProcedure> docsProcedure)
        {
            _repo = repo;
            _chedRepo = chedRepo;
            _categRepo = categRepo;
            _senderRepo = senderRepo;
            _scategRepo = scategRepo;
            _userManager = userManager;
            _procedureRepo = procedureRepo;
            _docTrackingRepo = docTrackingRepo;
            _mapper = mapper;
            _fileUploader = fileUploader;
            _docsProcedure = docsProcedure;
        }
        [BindProperty]
        public ComposeInputModel InputModel { get; set; }
        public List<CHEDPersonelListViewModel> Reviewers { get; set; }

        public string SenderId { get; set; }
        public List<Category> Categories { get; set; }
        public List<SubCategory> SubCategories { get; set; }
        public async Task OnGetAsync()
        {
            var reviewers = await _chedRepo.CHEDPersonelRecords();
            var categories = await _categRepo.GetAll();
            var subcategories = await _scategRepo.GetAll();

            var user = await _userManager.FindByEmailAsync(User.Identity?.Name);
            var senders = await _senderRepo.GetAll();
            var senderId = senders.FirstOrDefault(x => x.IdentityUserId == user?.Id)?.Id;

            InputModel = new ComposeInputModel()
            {
                SenderId = (int)senderId
            };


            Reviewers = reviewers.ToList();
            Categories = categories.ToList();
            SubCategories = subcategories.ToList();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var convert = _mapper.Map<DocumentAttachment>(InputModel);
            convert.FileName = await _fileUploader.Uploadfile(InputModel.File,"Documents");
            var docTracking = new DocumentTracking()
            {
                AddedAt = DateTime.Now,
                UpdatedAt = DateTime.Now,
                ReviewerStatus = ReviewerStatus.ToReceived,
                ReviewerId = InputModel.ReviewerId,
                DocsAttachment = convert
            };
            await _repo.Add(convert);
            await _docTrackingRepo.Add(docTracking);

            var procedures = await _procedureRepo.GetAll();
            foreach(var procedure in procedures)
            {
                await _docsProcedure.Add(new DocumentProcedure()
                {
                    DocumentAttachment = convert,
                    ProcedureDescription = procedure.Description,
                    ProcedureTitle = procedure.ProcedureTitle
                });
            }
            TempData["validation-message"] = "Successfully added";
            return RedirectToPage("/Application/Document/Pending/Index");
        }
    }
}
