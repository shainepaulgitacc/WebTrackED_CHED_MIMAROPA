using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebTrackED_CHED_MIMAROPA.Model.Entities;
using WebTrackED_CHED_MIMAROPA.Model.Repositories.Contracts;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.InputViewModel;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Management.OfficeManagement
{
    public class IndexModel:BasePageModel<Office,OfficeInputModel>
    {
        private IBaseRepository<Office> _repo;
        public IndexModel(IBaseRepository<Office> officeRepo,IMapper map):base(officeRepo,map)
        {
            _repo = officeRepo;
        }
        public async Task OnGetAsync()
        {
            var offices = await _repo.GetAll();
            Records = offices.ToList();
        }
    }
}
