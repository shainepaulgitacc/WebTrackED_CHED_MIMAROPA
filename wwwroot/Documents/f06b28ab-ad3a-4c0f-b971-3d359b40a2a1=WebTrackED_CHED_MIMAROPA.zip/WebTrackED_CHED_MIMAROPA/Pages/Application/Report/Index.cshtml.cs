using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Razor.Language.Intermediate;
using WebTrackED_CHED_MIMAROPA.Model.Entities;
using WebTrackED_CHED_MIMAROPA.Model.Repositories.Contracts;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.ListViewModel;
using WebTrackED_CHED_MIMAROPA.Model.ViewModel.RequestModel;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Report
{
    public class IndexModel : PageModel
    {
        private readonly IDocumentAttachmentRepository _docsAttachRepo;
        private readonly IBaseRepository<SubCategory> _subCategRepo;
        public IndexModel(IDocumentAttachmentRepository docsAttachRepo,
            IBaseRepository<SubCategory> subCategRepo)
        {
            _docsAttachRepo = docsAttachRepo;
            _subCategRepo = subCategRepo;
        }
        public ReportsRecords Records { get; set; }
        public IEnumerable<SubCategory> SubCategories { get; set; }
        public int[] SelectItems { get; set; }
        public async Task OnGetAsync(FilteringRequestModel request)
        {
            SubCategories = await _subCategRepo.GetAll();
            Records = await _docsAttachRepo.GetRecordsPiginated(request.CurrentPage,request.PageSize,request.SubCategory,request.Prioritization,request.Status);
            if(request.Status != null && request.Prioritization != null && request.SubCategory != null)
            TempData["validation-message"] = "Successfully filtered the records";
        }
    }
}
