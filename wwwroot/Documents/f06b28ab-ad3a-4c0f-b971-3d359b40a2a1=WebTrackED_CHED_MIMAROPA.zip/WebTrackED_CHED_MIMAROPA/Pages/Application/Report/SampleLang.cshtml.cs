using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Report
{
    public class SampleLangModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
