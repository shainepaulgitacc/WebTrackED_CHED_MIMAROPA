using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Profiles
{
    public class IndexModel : PageModel
    {
        public string PreviousPage { get; set; }
        public async Task OnGetAsync()
        {
           
        }
    }
}
