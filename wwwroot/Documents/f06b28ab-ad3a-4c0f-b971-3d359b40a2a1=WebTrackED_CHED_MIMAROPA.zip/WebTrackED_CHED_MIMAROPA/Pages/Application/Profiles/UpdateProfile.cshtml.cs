using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebTrackED_CHED_MIMAROPA.Pages.Application.Profiles
{
    public class UpdateProfileModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
