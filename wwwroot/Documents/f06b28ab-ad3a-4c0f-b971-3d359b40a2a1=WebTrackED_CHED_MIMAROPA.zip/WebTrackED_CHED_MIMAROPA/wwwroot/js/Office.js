﻿/*$(function(){
    $("#btn-add-row").on("click", function () {
        let newRow = $("<tr>")
            .append($("<td>").html("<span class='text-primary'>Id 001</span>"))
            .append($("<td>").text("Sample Data"))
            .append($("<td>").text("Sample Data"))
            .append($("<td>").text("Sample Data"))
            .append($("<td>").html("<button class='btn btn-success'><i class='fa-solid fa-square-pen'></i></button>"));
        $("#table-data tbody").append(newRow);
    })
})*/