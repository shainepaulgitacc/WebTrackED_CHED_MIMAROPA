﻿$(function () {
    $("#sample").addClass("text-danger");
    $("#menu-toggle").on("click", function () {
        console.log("hello");
        $("#sidebar").toggleClass("sidebar-hide");
        $("#sidebar").toggleClass("sidebar-show");
    })
    let menus = $(".menus");
    menus.each(function () {
        // Use .on() to attach the click event
        $(this).on("click", function () {
            if (!$(this).hasClass("active")) {
                menus.removeClass("active");
            }
            $(this).toggleClass("active");
        });

    });
    //data tables
    new DataTable('#table-data');
    //alert
    $("#alert-close").on("click", function () {
        if ($("#alert").hasClass("active-alert")) {
            $("#alert").removeClass("active-alert");
        }
    })
});
