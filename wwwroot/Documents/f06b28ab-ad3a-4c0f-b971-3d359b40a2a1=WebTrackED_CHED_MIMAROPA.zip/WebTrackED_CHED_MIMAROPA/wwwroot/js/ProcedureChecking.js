﻿$(function () {
    $("#btn-procceed").on("click", function () {
        let selectedId = [];
        $(".procedure-input").each(function () {
            if ($(this).is(":checked")) {
                selectedId.push($(this).val());
            }
        })
        let joinedIds = selectedId.join(",");
        $("#selected-ids").val(joinedIds);
        $("#new-reviewer").val($('input[name=reviewer]:checked').val());
        $("#form-procceed").submit();
    })

    $(".procedure-input").on("change", function () {
        if ($('.procedure-input:checked').length === $('.procedure-input').length) {
            $('#btn-approved').removeClass('d-none');
            $('#btn-procceed').addClass('d-none');
            $('input[name=reviewer]').prop('disabled', true);
        }
        else {
            $('#btn-approved').addClass('d-none');
            $('#btn-procceed').removeClass('d-none');
            $('input[name=reviewer]').prop('disabled', false);
        }
    })
})